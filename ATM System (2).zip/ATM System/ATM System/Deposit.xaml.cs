﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ATM_System
{
    /// <summary>
    /// Interaction logic for Deposit.xaml
    /// </summary>
    public partial class Deposit : Window
    {
        public Deposit()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string account_name = AccountNamelabel.Content.ToString();
            string account_balance = AccountBalancelabel.Content.ToString();
            string account_type = AccountTypelabel.Content.ToString();
            string deposit = Depositlabel.Content.ToString();

            MessageBox.Show("Account Name:Ayesha " + account_name + "\nAccount Balance:5000 " + account_balance + "\nAccount Type: Savings" + account_type + "\nDeposit: " + deposit);

        }
        private void PreviousButton_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Previous Button Clicked");
        }
        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            AccountNamelabel.Content = "";
            AccountBalancelabel.Content = "";
            Depositlabel.Content = "";
            AccountTypeComboBox.SelectedIndex = -1;
        }
        private void ExitButton_Click(object sender, RoutedEventArgs e) { 

            Trancation_page trancation_Page = new Trancation_page();
            trancation_Page.Show();
            this.Close();
        }
    }
}
