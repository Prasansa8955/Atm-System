﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ATM_System
{
    /// <summary>
    /// Interaction logic for Withdraw.xaml
    /// </summary>
    public partial class Withdraw : Window
    {
        public Withdraw()
        {
            InitializeComponent();
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string account_name = AccountNamelabel.Content.ToString();
            string account_balance = AccountBalancelabel.Content.ToString();
            string account_type = AccountTypelabel.Content.ToString();
            string withdraw = Withdrawal.Content.ToString();

            if (string.IsNullOrWhiteSpace(account_name) || string.IsNullOrWhiteSpace(account_balance) || string.IsNullOrWhiteSpace(account_type) || string.IsNullOrWhiteSpace(withdraw))
            {
                MessageBox.Show("Please fill all the fields.");
                return;
            }
            if (!double.TryParse(withdraw, out double withdrawAmount))
            {
                MessageBox.Show("Please enter a valid amount.");
                return;
            }
          /*  if (withdraw > account_balance) { 
            MessageBox.Show("Insufficient balance.");
                
                return;
                
            }*/

            
        }
    }
}
