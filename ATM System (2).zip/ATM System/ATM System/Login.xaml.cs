﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ATM_System
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();

        }
        private void Login_click(object sender, RoutedEventArgs e)
        {

            


        }
        private void SignUp_Click(object sender, RoutedEventArgs e) {
            MessageBox.Show("Sign Up feature not implemented yet.");
        }

        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string accounNumbr = AccountNumberBox.Text;
            string pin = PinBox.Password;

            if (accounNumbr == "12345" && pin == "6789")
            {
                MessageBox.Show("Login Successful!");
                Trancation_page trancation_Page = new Trancation_page();
                trancation_Page.Show();
                this.Close();



            }
            else
            {
                MessageBox.Show("Incorrect Account Number or PIN");

            }
        }
    }
}
